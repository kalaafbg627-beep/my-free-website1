// Supabase configuration
const supabaseUrl = 'https://pxqsoldkmatvhxyyukgk.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB4cXNvbGRrbWF0dmh4eXl1a2drIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1MDgxNzgsImV4cCI6MjA3NDA4NDE3OH0.h_sHcjs5VVpzgIIiXhMEoZ-Bw30XaVDqR4OW_tYOJCY';
const supabase = supabase.createClient(supabaseUrl, supabaseKey);

// Section Navigation
function showSection(sectionId) {
    document.querySelectorAll('main section').forEach(sec => sec.classList.remove('active-section'));
    document.getElementById(sectionId).classList.add('active-section');
}

// Signup Function
const signupForm = document.getElementById('signupForm');
const signupMessage = document.getElementById('signupMessage');

signupForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const username = document.getElementById('signupUsername').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;

    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
        signupMessage.textContent = error.message;
    } else {
        await supabase.from('profiles').insert([{ id: data.user.id, username }]);
        signupMessage.textContent = "Signup successful! Please login.";
        signupForm.reset();
    }
});

// Login Function
const loginForm = document.getElementById('loginForm');
const loginMessage = document.getElementById('loginMessage');

loginForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
        loginMessage.textContent = error.message;
    } else {
        localStorage.setItem('user', JSON.stringify(data.user));
        showProfile();
        showSection('profile');
        loginMessage.textContent = "Login successful!";
    }
});

// Show Profile
async function showProfile() {
    const profileDiv = document.getElementById('profileInfo');
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
        const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
        if (data) {
            profileDiv.innerHTML = `
                <p><strong>Username:</strong> ${data.username}</p>
                <p><strong>Email:</strong> ${user.email}</p>
            `;
        }
    } else {
        profileDiv.innerHTML = "<p>Not logged in.</p>";
    }
}

// Logout
function logout() {
    supabase.auth.signOut();
    localStorage.removeItem('user');
    showSection('home');
    alert("You have been logged out.");
}